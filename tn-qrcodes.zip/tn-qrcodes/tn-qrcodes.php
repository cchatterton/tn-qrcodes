<?php
/**
 * Plugin Name: TN QR Codes
 * Description: Adds QR codes to public post types and creates trackable QR codes for any URL.
 * Version: 1.6.1
 * Requires at least: 7.0
 * Requires PHP: 7.4
 * Author: Techn
 * Author URI: https://techn.com.au
 * Update URI: https://github.com/cchatterton/tn-qrcodes
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Techn Controller API: 1
 * Text Domain: tn-qrcodes
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TN_QR_VERSION', '1.6.1');
define('TN_QR_PLUGIN_FILE', __FILE__);
define('TN_QR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TN_QR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('TN_QR_META_SOURCE', '_tn_qr_utm_source');
define('TN_QR_META_MEDIUM', '_tn_qr_utm_medium');
define('TN_QR_META_CAMPAIGN', '_tn_qr_utm_campaign');

require_once TN_QR_PLUGIN_DIR . 'phpqrcode/qrlib.php';
require_once TN_QR_PLUGIN_DIR . 'functions/assets.php';
require_once TN_QR_PLUGIN_DIR . 'functions/qrcodes.php';
require_once TN_QR_PLUGIN_DIR . 'functions/tracked-links.php';

require_once __DIR__ . '/functions/controller-client.php';
tnuc_client_register(__FILE__, 'tn-qrcodes');
